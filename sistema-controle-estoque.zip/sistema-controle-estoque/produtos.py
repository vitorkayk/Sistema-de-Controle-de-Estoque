"""Cadastro e consulta de produtos."""

produtos = {
    "P001": {"nome": "Arroz 5 kg", "quantidade": 20},
    "P002": {"nome": "Feijão 1 kg", "quantidade": 15},
}


def listar_produtos():
    if not produtos:
        print("Nenhum produto cadastrado.")
        return
    print("\n--- PRODUTOS CADASTRADOS ---")
    for codigo, produto in produtos.items():
        print(f"{codigo} - {produto['nome']} | Quantidade: {produto['quantidade']}")


def cadastrar_produto(codigo, nome, quantidade):
    if codigo in produtos:
        print("Já existe um produto com esse código.")
        return False
    if quantidade < 0:
        print("A quantidade não pode ser negativa.")
        return False
    produtos[codigo] = {"nome": nome, "quantidade": quantidade}
    print("Produto cadastrado com sucesso.")
    return True
