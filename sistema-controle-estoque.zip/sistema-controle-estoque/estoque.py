"""Sistema de Controle de Estoque."""

from produtos import listar_produtos, cadastrar_produto, produtos


def registrar_movimentacao(codigo, quantidade, operacao):
    if codigo not in produtos:
        print("Produto não encontrado.")
        return
    if quantidade <= 0:
        print("Informe uma quantidade maior que zero.")
        return

    produto = produtos[codigo]
    if operacao == "saida":
        if quantidade > produto["quantidade"]:
            print("Estoque insuficiente.")
            return
        produto["quantidade"] -= quantidade
    else:
        produto["quantidade"] += quantidade

    with open("historico.txt", "a", encoding="utf-8") as arquivo:
        arquivo.write(
            f"{operacao.upper()} | {codigo} | {produto['nome']} | {quantidade} unidade(s)\n"
        )
    print("Movimentação registrada com sucesso.")


def menu():
    while True:
        print("\n=== SISTEMA DE CONTROLE DE ESTOQUE ===")
        print("1 - Listar produtos")
        print("2 - Cadastrar produto")
        print("3 - Registrar entrada")
        print("4 - Registrar saída")
        print("0 - Sair")
        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            listar_produtos()
        elif opcao == "2":
            codigo = input("Código: ").strip().upper()
            nome = input("Nome: ").strip()
            try:
                cadastrar_produto(codigo, nome, int(input("Quantidade inicial: ")))
            except ValueError:
                print("Digite uma quantidade válida.")
        elif opcao in ("3", "4"):
            codigo = input("Código do produto: ").strip().upper()
            try:
                quantidade = int(input("Quantidade: "))
                operacao = "entrada" if opcao == "3" else "saida"
                registrar_movimentacao(codigo, quantidade, operacao)
            except ValueError:
                print("Digite uma quantidade válida.")
        elif opcao == "0":
            print("Encerrando o sistema.")
            break
        else:
            print("Opção inválida.")


if __name__ == "__main__":
    menu()
