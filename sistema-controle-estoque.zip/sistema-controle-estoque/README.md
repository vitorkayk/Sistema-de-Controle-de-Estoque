# Sistema de Controle de Estoque

Projeto acadêmico simples para demonstrar o uso do Git e GitHub no gerenciamento de configuração de software.

## Funcionalidades
- Cadastrar produtos.
- Listar produtos.
- Registrar entrada e saída de unidades.

## Como executar
Com Python 3 instalado, execute:
```bash
python estoque.py
```

## Arquivos
- `estoque.py`: menu e operações do estoque.
- `produtos.py`: cadastro e listagem.
- `historico.txt`: movimentações registradas.

## Objetivo
Praticar clonagem, edição de arquivos, `git status`, `git add`, `git commit` e `git push`.
